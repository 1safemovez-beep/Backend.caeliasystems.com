// Owner-only auth. Alicia's token lives in ENV (OWNER_TOKEN), never in code.
// All /api/* routes require: Authorization: Bearer <token>
import { config } from "../config.js";

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!config.ownerToken || token !== config.ownerToken) {
    return res.status(401).json({ ok: false, error: "UNAUTHORIZED" });
  }
  req.actor = "alicia"; // single owner; roles expand here later if Alicia decides
  next();
}
