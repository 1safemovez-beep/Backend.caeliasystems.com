# Caelia Backend Core

This package is the backend foundation corresponding to the Brain Module + Expandable Container diagram.

## Included
- Core API server
- Task interpreter
- Agent orchestration boundary
- Memory/context storage
- Tool/app registry
- Permissions and authority boundary
- Audit log
- Expandable knowledge/files/memory/backups folders
- Architecture manifest

## Run
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and configure it.
3. Run `npm start`.
4. Health check: `GET /api/health`

Default port: `8787`.

## Important
This is the **foundation**, not a claim that every AI provider, external app, or production security control is already connected. Provider credentials should be stored as deployment secrets, not in frontend code or committed files.

The Core intentionally separates:
- reasoning from authority
- memory from identity
- planning from execution
- skills from permissions
- delegation from ownership
