const { createPlan } = require("../core/taskInterpreter");
const { orchestrate } = require("../core/agentOrchestrator");
const { getContext, saveMemory } = require("../core/memoryContext");
const { authorize } = require("../security/permissions");
const { audit } = require("../security/audit");
const { listTools } = require("../core/toolManager");

module.exports = async ({ req, body, dataDir, name }) => {
  const url = new URL(req.url, "http://localhost");

  if (req.method === "GET" && url.pathname === "/api/health") {
    return { body: {
      ok: true,
      service: name,
      status: "online",
      architecture: "Caelia Core",
      timestamp: new Date().toISOString()
    }};
  }

  if (req.method === "GET" && url.pathname === "/api/tools") {
    return { body: { ok: true, tools: listTools() }};
  }

  if (req.method === "POST" && url.pathname === "/api/plan") {
    const user = body.user || "Alicia";
    const request = String(body.request || "").trim();
    if (!request) return { status: 400, body: { ok: false, error: "request is required" } };

    const permission = authorize({ actor: user, action: "plan", risk: "low" });
    audit(dataDir, { event: "plan_requested", actor: user, request });

    return { body: {
      ok: true,
      permission,
      plan: createPlan(request)
    }};
  }

  if (req.method === "POST" && url.pathname === "/api/execute") {
    const user = body.user || "Alicia";
    const request = String(body.request || "").trim();
    const risk = body.risk || "medium";
    if (!request) return { status: 400, body: { ok: false, error: "request is required" } };

    const permission = authorize({ actor: user, action: "execute", risk });
    if (!permission.allowed) {
      audit(dataDir, { event: "execution_denied", actor: user, request, risk });
      return { status: 403, body: { ok: false, permission }};
    }

    const context = getContext(dataDir, body.memoryKeys || []);
    const result = await orchestrate({ request, context });
    audit(dataDir, { event: "execution_completed", actor: user, request, result });
    return { body: { ok: true, permission, result }};
  }

  if (req.method === "POST" && url.pathname === "/api/memory") {
    const key = String(body.key || "").trim();
    const value = body.value;
    if (!key) return { status: 400, body: { ok: false, error: "key is required" } };
    saveMemory(dataDir, key, value);
    audit(dataDir, { event: "memory_saved", actor: body.user || "Alicia", key });
    return { body: { ok: true, key }};
  }

  if (req.method === "GET" && url.pathname === "/api/context") {
    return { body: { ok: true, context: getContext(dataDir, []) }};
  }

  return { status: 404, body: { ok: false, error: "Not found" }};
};
