const fs = require("fs");
const path = require("path");

function memoryPath(dataDir, key) {
  return path.join(dataDir, "memory", `${key.replace(/[^a-zA-Z0-9._-]/g, "_")}.json`);
}

function saveMemory(dataDir, key, value) {
  fs.writeFileSync(memoryPath(dataDir, key), JSON.stringify({
    key, value, updatedAt: new Date().toISOString()
  }, null, 2));
}

function getContext(dataDir, keys) {
  const dir = path.join(dataDir, "memory");
  const names = fs.readdirSync(dir).filter(n => n.endsWith(".json"));
  const selected = keys.length ? names.filter(n => keys.includes(n.replace(/\.json$/, ""))) : names;
  const out = {};
  for (const name of selected) {
    try {
      const item = JSON.parse(fs.readFileSync(path.join(dir, name), "utf8"));
      out[item.key] = item.value;
    } catch {}
  }
  return out;
}

module.exports = { saveMemory, getContext };
