const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = Number(process.env.PORT || 8787);
const DATA_DIR = path.resolve(process.env.DATA_DIR || "./data");
const NAME = process.env.CAELIA_NAME || "Caelia";

for (const dir of ["knowledge", "files", "memory", "backups"]) {
  fs.mkdirSync(path.join(DATA_DIR, dir), { recursive: true });
}

const json = (res, status, body) => {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": process.env.CORS_ORIGIN || "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  });
  res.end(JSON.stringify(body));
};

const readBody = (req) => new Promise((resolve, reject) => {
  let raw = "";
  req.on("data", chunk => {
    raw += chunk;
    if (raw.length > 2_000_000) {
      req.destroy();
      reject(new Error("Request too large"));
    }
  });
  req.on("end", () => {
    if (!raw) return resolve({});
    try { resolve(JSON.parse(raw)); }
    catch { reject(new Error("Invalid JSON")); }
  });
  req.on("error", reject);
});

const routes = require("./src/routes/api");

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return json(res, 204, {});
  try {
    const result = await routes({ req, body: await readBody(req), dataDir: DATA_DIR, name: NAME });
    return json(res, result.status || 200, result.body);
  } catch (err) {
    console.error(err);
    return json(res, 500, { ok: false, error: "Internal server error" });
  }
});

server.listen(PORT, () => {
  console.log(`${NAME} backend listening on http://localhost:${PORT}`);
});
