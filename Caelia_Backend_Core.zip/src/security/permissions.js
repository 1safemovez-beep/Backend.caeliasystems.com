function authorize({ actor, action, risk }) {
  const isOwner = actor === "Alicia" || actor === process.env.ADMIN_EMAIL;

  if (risk === "high" && !isOwner) {
    return { allowed: false, reason: "High-risk action requires Alicia/authorized owner approval." };
  }

  return {
    allowed: true,
    actor,
    action,
    risk,
    authority: isOwner ? "owner" : "delegated",
    note: "Permission does not alter Caelia Core identity."
  };
}

module.exports = { authorize };
