const tools = new Map();

function registerTool({ name, description, risk = "medium", handler }) {
  tools.set(name, { name, description, risk, handler });
}

function listTools() {
  return [...tools.values()].map(({ name, description, risk }) => ({ name, description, risk }));
}

module.exports = { registerTool, listTools };
