const fs = require("fs");
const path = require("path");

function audit(dataDir, event) {
  const file = path.join(dataDir, "audit.log");
  fs.appendFileSync(file, JSON.stringify({
    ...event,
    timestamp: new Date().toISOString()
  }) + "\n");
}

module.exports = { audit };
