export { fawn } from "./fawn.js";
export { nova } from "./nova.js";

import { fawn } from "./fawn.js";
import { nova } from "./nova.js";
export const agents = { fawn, nova };
