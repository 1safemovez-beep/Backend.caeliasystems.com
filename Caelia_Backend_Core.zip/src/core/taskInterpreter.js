function createPlan(request) {
  const text = request.toLowerCase();
  const steps = [];

  if (/(remember|save|store|memory)/.test(text)) steps.push("memory");
  if (/(email|calendar|github|app|api|tool)/.test(text)) steps.push("tool_or_integration");
  if (/(build|create|code|file|dashboard)/.test(text)) steps.push("build_or_file");
  if (steps.length === 0) steps.push("reason_and_respond");

  return {
    request,
    intent: "interpreted",
    steps,
    authority: "Alicia",
    executionPolicy: "permission_required_for_consequential_actions"
  };
}

module.exports = { createPlan };
